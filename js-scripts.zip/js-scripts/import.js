#!/usr/bin/env node
const admin = require('firebase-admin');
const fs = require('fs');
const serviceAccount = require('./dependencies/seracc.json');

admin.initializeApp({
	credential: admin.credential.cert(serviceAccount),
	databaseURL: 'https://firestore.googleapis.com/v1/projects/web-ios-android-desktop/databases/(default)/documents',
});

const db = admin.firestore();

const data = JSON.parse(fs.readFileSync('./dependencies/database.json', 'utf8'));

async function importData() {
	for (const [collection, documents] of Object.entries(data)) {
		const collectionRef = db.collection(collection);
		for (const [id, document] of Object.entries(documents)) {
			await collectionRef.doc(id).set(document);
			console.log(`Document ${id} added to collection ${collection}`);
		}
	}
}

importData().then(() => {
	console.log('Data import complete');
}).catch((error) => {
	console.error('Error importing data:', error);
});
